FactoryBot.define do
  factory :idea do
    category_id { 1 }
    body { 'test_body' }
  end
end