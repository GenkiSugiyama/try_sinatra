FactoryBot.define do
  factory :category do
    name { 'test_category' }
  end
end