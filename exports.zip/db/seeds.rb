Category.create!(
  [
      {
      name: 'Sports',
    },
    {
      name: 'Study',
    }
  ]
)

Idea.create!(
  [
    {
      category_id: 1,
      body: 'badminton',
    },
    {
      category_id: 2,
      body: 'Learn Ruby',
    }
  ]
)